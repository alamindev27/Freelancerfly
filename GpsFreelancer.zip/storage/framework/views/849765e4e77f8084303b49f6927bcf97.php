<?php $__env->startSection('content'); ?>
<div class="page-content">

    <div class="wt-bnr-inr overlay-wraper bg-center"
        style="background-image:url(<?php echo e(asset('assets/frontend/user/images/banner/1.jpg')); ?>);">
        <div class="overlay-main site-bg-white opacity-01"></div>
        <div class="container">
            <div class="wt-bnr-inr-entry">
                <div class="banner-title-outer">
                    <div class="banner-title-name">
                        <h2 class="wt-title"><?php echo e($data->heading); ?></h2>
                    </div>
                </div>
                <div>
                    <ul class="wt-breadcrumb breadcrumb-style-2">
                        <li><a href="index.html">Home</a></li>
                        <li><?php echo e($data->heading); ?></li>
                    </ul>
                </div>


            </div>
        </div>
    </div>




    <div class="section-full p-t100 p-b40 site-bg-white twm-how-it-work-area2" id="howitwork">

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <?php echo e($data->content); ?>

                </div>
            </div>
        </div>
    </div>






</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\GpsFreelancer\resources\views\privacyPolicy.blade.php ENDPATH**/ ?>