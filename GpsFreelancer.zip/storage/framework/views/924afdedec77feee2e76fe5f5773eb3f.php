<?php $__env->startSection('styles'); ?>
    <style>
        .all-dashboard-icon {
            width: 13px !important;
        }
    </style>

    <style>
        .error_input {
            border: 1px solid #f00 !important;
        }

        .dropify-wrapper {
            margin-bottom: 10px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-wraper" style="transform: none;">
        <div class="page-content" style="transform: none;">
            <div class="section-full p-t70  p-b70 site-bg-white" style="transform: none;">
                <div class="container" style="transform: none;">
                    <div class="row" style="transform: none;">

                        <?php echo $__env->make('partials.profile-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                        <div class="col-xl-9 col-lg-8 col-md-12 m-b30">
                            <div class="twm-right-section-panel site-bg-gray">

                                <div class="panel panel-default">
                                    <div class="panel-heading wt-panel-heading p-a20">
                                        <h4 class="panel-tittle m-a0">Plan</h4>
                                    </div>
                                    <div class="row justify-content-center">
                                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-4 my-3">
                                                <div class="card">
                                                    <div class="card-header bg-primary text-white text-center">
                                                        <h3 class="text-white"><?php echo e($plan->plan_name); ?></h2>
                                                    </div>
                                                    <div class="card-body Promoter Award_body">
                                                        <span style="color: #3498DB" ;="">
                                                            <p><i class="fas fa-check-circle text-blue"></i>&nbsp;&nbsp; Job Post Fee cost <?php echo e($plan->job_post_fee); ?>%</p>
                                                            <p><i class="fas fa-check-circle text-green"></i> &nbsp;&nbsp;Withdraw Fee Less <?php echo e($plan->withdraw_fee); ?>%</p>
                                                            <p><i class="fas fa-check-circle text-blue"></i> &nbsp;&nbsp; Get Post Boost Duration <?php echo e($plan->post_bost_duration); ?> Minute</p>
                                                            <p><i class="fas fa-check-circle text-green"></i>&nbsp;&nbsp; Get Daily Spin Limit <?php echo e($plan->daily_spin_limit); ?></p>
                                                            <p class="font-weight-bold"><i class="fas fa-check-circle text-green"></i>&nbsp;&nbsp; Get Deposit Referral Commission <?php echo e($plan->deposit_refer_commission); ?>%</p>
                                                            <p><i class="fas fa-check-circle text-green"></i>&nbsp;&nbsp; Get Task Commission <?php echo e($plan->task_commission); ?>%</p>
                                                            <?php if($plan->geen_mark_badge == 'yes'): ?>
                                                                <p><i class="fas fa-check-circle text-green"></i>&nbsp;&nbsp; <span class="text-capitalize">Green Mark Badge</span></p>
                                                            <?php endif; ?>
                                                            <?php if($plan->profile_mark_badge == 'yes'): ?>
                                                                <p><i class="fas fa-check-circle text-green"></i>&nbsp;&nbsp; <span class="text-capitalize">Profile Mark Badge</span></p>
                                                            <?php endif; ?>
                                                            <?php if($plan->live_phone_call_support == 'yes'): ?>
                                                                <p><i class="fas fa-check-circle text-green"></i>&nbsp;&nbsp; <span class="text-capitalize"> Live Phone Call Support</span></p>
                                                            <?php endif; ?>
                                                            <p class="text-center font-weight-bold"><b>Need 500 Refer to Active</b></p>
                                                            <div class="text-center">
                                                                <hr>
                                                                <button class="btn btn-primary">Buy at $<?php echo e($plan->price); ?></button>
                                                             </div>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        

                                     </div>

                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('.dropify').dropify();
        $('.add_portfolio').click(function() {
            $(this).before('<input name="portfolio[]" accept="image/*" type="file" class="dropify"/>')
            $('.dropify').dropify();
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\GpsFreelancer\resources\views\user\plan\index.blade.php ENDPATH**/ ?>