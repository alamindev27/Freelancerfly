<?php $__currentLoopData = $subCategries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <label for="sbcategory-<?php echo e($subCategory->id); ?>" rate="<?php echo e($subCategory->rate); ?>" subcategory_name="<?php echo e($subCategory->subcategory_name); ?>"  class="subcategory-item <?php echo e($loop->index == 0 ? 'active' : ''); ?>" min_price="0.02" >
        <div><?php echo e($subCategory->subcategory_name); ?></div>
        <input type="radio" id="sbcategory-<?php echo e($subCategory->id); ?>" min_price="0.02" value="<?php echo e($subCategory->id); ?>" name="subcategory_id" class="subcategory_input d-none">
    </label>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH F:\xampp\htdocs\GpsFreelancer\resources\views/client/get-subcategories.blade.php ENDPATH**/ ?>