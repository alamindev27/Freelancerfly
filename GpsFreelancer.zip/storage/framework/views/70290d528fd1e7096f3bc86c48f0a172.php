<?php echo $__env->make('admin.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Main Sidebar Container -->
<?php echo $__env->make('admin.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <?php echo $__env->yieldContent('content'); ?>
</div>
<!-- /.content-wrapper -->
<!-- Main Footer -->
<?php echo $__env->make('admin.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH F:\xampp\htdocs\GpsFreelancer\resources\views/admin/layouts/app_admin.blade.php ENDPATH**/ ?>