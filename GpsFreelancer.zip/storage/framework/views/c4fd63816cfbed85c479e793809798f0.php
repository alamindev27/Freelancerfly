<?php $__env->startSection('styles'); ?>
    <style>
        .all-dashboard-icon {
            width: 13px !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-wraper" style="transform: none;">
        <div class="page-content" style="transform: none;">
            <div class="section-full p-t70  p-b70 site-bg-white" style="transform: none;">
                <div class="container" style="transform: none;">
                    <div class="row" style="transform: none;">

                        <?php echo $__env->make('partials.profile-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




                        <div class="col-xl-9 col-lg-8 col-md-12 m-b30">

                            <div class="twm-right-section-panel site-bg-gray">



                                <div class="panel panel-default">
                                    <div class="panel-heading wt-panel-heading p-a20">
                                        <h4 class="panel-tittle m-a0"><svg style="width: 20px" class="svg-inline--fa fa-suitcase me-2"
                                                aria-hidden="true" focusable="false" data-prefix="fas" data-icon="suitcase"
                                                role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"
                                                data-fa-i2svg="">
                                                <path fill="currentColor"
                                                    d="M176 56V96H336V56c0-4.4-3.6-8-8-8H184c-4.4 0-8 3.6-8 8zM128 96V56c0-30.9 25.1-56 56-56H328c30.9 0 56 25.1 56 56V96v32V480H128V128 96zM64 96H96V480H64c-35.3 0-64-28.7-64-64V160c0-35.3 28.7-64 64-64zM448 480H416V96h32c35.3 0 64 28.7 64 64V416c0 35.3-28.7 64-64 64z">
                                                </path>
                                            </svg><!-- <i class="fa fa-suitcase me-2"></i> Font Awesome fontawesome.com -->Inbox
                                        </h4>
                                    </div>
                                    <div class="panel-body wt-panel-body p-a20 m-b30 ">
                                        <div class="wt-admin-dashboard-msg-2">

                                            <div class="wt-dashboard-msg-user-list">
                                                <div class="user-msg-list-btn-outer">
                                                    <button class="user-msg-list-btn-close">Close</button>
                                                    <button class="user-msg-list-btn-open">User Message</button>
                                                </div>

                                                



                                                <div class="scroll-wrapper wt-dashboard-msg-search-list scrollbar-macosx"
                                                    style="position: relative;">
                                                    <div class="wt-dashboard-msg-search-list scrollbar-macosx scroll-content" id="conversation_list" style="position: relative; height: 700px; margin-bottom: 0px; margin-right: 0px; max-height: none;">

                                                        <?php echo $__env->make('partials.message-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                                    </div>
                                                    <div class="scroll-element scroll-x">
                                                        <div class="scroll-element_outer">
                                                            <div class="scroll-element_size"></div>
                                                            <div class="scroll-element_track"></div>
                                                            <div class="scroll-bar" style="width: 0px;"></div>
                                                        </div>
                                                    </div>
                                                    <div class="scroll-element scroll-y">
                                                        <div class="scroll-element_outer">
                                                            <div class="scroll-element_size"></div>
                                                            <div class="scroll-element_track"></div>
                                                            <div class="scroll-bar" style="height: 0px;"></div>
                                                        </div>
                                                    </div>
                                                </div>


                                            </div>


                                            <div id="msg-chat-wrap" class="wt-dashboard-msg-box">
                                                
                                                <div class="single-user-msg-conversation scrollbar-macosx "
                                                    id="msg-chat-list" style="overflow-x:scroll">
                                                    <div class="single-user-comment-wrap sigle-user-reply">
                                                        <div class="row justify-content-end">
                                                            <div class="col-12">
                                                                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <div class="single-user-comment-block clearfix">
                                                                        <div class="single-user-com-pic">
                                                                            <?php if($message->sender_id == auth()->user()->id): ?>
                                                                                <img src="<?php echo e(asset(getUser($message->resiver_id)->avatar)); ?>" alt="">
                                                                            <?php else: ?>
                                                                                <img src="<?php echo e(asset(getUser($message->sender_id)->avatar)); ?>" alt="">
                                                                            <?php endif; ?>
                                                                        </div>
                                                                        <div class="single-user-com-text"><?php echo e($message->message); ?></div>
                                                                        <div class="single-user-msg-time">
                                                                            <svg style="width: 20px" class="svg-inline--fa fa-check text-wright" style="font-size: 10px;" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
                                                                                <path fill="currentColor" d="M470.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L192 338.7 425.4 105.4c12.5-12.5 32.8-12.5 45.3 0z">
                                                                                </path>
                                                                            </svg>
                                                                        </div>
                                                                    </div>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>

                                                <div class="single-msg-reply-comment">

                                                    <div class="publisher bt-1 border-light w-100">
                                                        <span class="user-icon">
                                                            <svg class="svg-inline--fa fa-user" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="user" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg="">
                                                                <path fill="currentColor" d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0S96 57.3 96 128s57.3 128 128 128zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512H418.3c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304H178.3z">
                                                                </path>
                                                            </svg>
                                                        </span>

                                                        <form action="<?php echo e(route('message.send')); ?>" id="conversation_form" method="post" class="w-100">
                                                            <?php echo csrf_field(); ?>
                                                            <input class="publisher-input message" type="text" name="message" placeholder="Write something" style="width: 93%">
                                                            <input type="text" name="sender_id" value="<?php echo e(auth()->user()->id); ?>">
                                                            <input type="text" name="resiver_id" value="<?php echo e($singleMessage->resiver_id); ?>">
                                                            <button type="submit" class="publisher-btn primary-btn-color" id="send_message" data-abc="true">
                                                                <svg class="svg-inline--fa fa-paper-plane" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="paper-plane" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
                                                                    <path fill="currentColor"
                                                                        d="M498.1 5.6c10.1 7 15.4 19.1 13.5 31.2l-64 416c-1.5 9.7-7.4 18.2-16 23s-18.9 5.4-28 1.6L284 427.7l-68.5 74.1c-8.9 9.7-22.9 12.9-35.2 8.1S160 493.2 160 480V396.4c0-4 1.5-7.8 4.2-10.7L331.8 202.8c5.8-6.3 5.6-16-.4-22s-15.7-6.4-22-.7L106 360.8 17.7 316.6C7.1 311.3 .3 300.7 0 288.9s5.9-22.8 16.1-28.7l448-256c10.7-6.1 23.9-5.5 34 1.4z">
                                                                    </path>
                                                                </svg>
                                                            </button>
                                                        </form>

                                                    </div>

                                                </div>


                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>




                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\GpsFreelancer\resources\views/both/message-reply.blade.php ENDPATH**/ ?>