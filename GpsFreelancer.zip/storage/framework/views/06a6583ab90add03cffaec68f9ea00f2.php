<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="twm-home2-banner-section site-bg-gray bg-cover">
            <div class="container">
                <div class="row align-items-center">

                    <div class="col-xl-6 col-lg-6 col-md-12 order-2 order-md-1 z-index-5">
                        <div class="twm-bnr-left-section">
                            <div class="twm-bnr-title-small">We Have <span class="site-text-secondry">50,000+</span>
                                Live Jobs</div>
                            <div class="twm-bnr-title-large"><?php echo e($banner->heading_part_1); ?> <span class="site-text-primary"><?php echo e($banner->heading_part_2); ?> </span>
                                <?php echo e($banner->heading_part_3); ?> </div>
                            <div class="twm-bnr-discription"><?php echo e($banner->text); ?></div>
                            <a href="login.html" class="site-button">Get Started</a>
                        </div>
                    </div>

                    <div class="col-xl-6 col-lg-6 col-md-12 twm-bnr-right-section order-1 order-md-2">
                        <div class="twm-bnr2-right-content">

                            <div class="twm-img-bg-circle-area2">
                                <div class="twm-outline-ring-wrap">
                                    <div class="twm-outline-ring-dott-wrap">
                                        <span class="outline-dot-1"></span>
                                        <span class="outline-dot-2"></span>
                                        <span class="outline-dot-3"></span>

                                        <div class="twm-small-ring-l scale-up-center"></div>
                                    </div>
                                </div>
                            </div>

                            <div class="twm-home-2-bnr-images">
                                <div class="bnr-image-1">
                                    <img src="<?php echo e(asset($banner->image_rounded)); ?>" alt="">
                                </div>
                                <div class="bnr-image-2">
                                    <img src="<?php echo e(asset($banner->image_circle)); ?>" alt="">
                                </div>
                                <div class="twm-small-ring-2 scale-up-center"></div>
                            </div>


                            <div class="twm-bnr-blocks twm-bnr-blocks-position-1">
                                <div class="twm-icon">
                                    <img src="<?php echo e(asset('assets/frontend/user/images/main-slider/slider2/icon-1.png')); ?>" alt="">
                                </div>
                                <div class="twm-content">
                                    <div class="tw-count-number text-clr-sky">
                                        <span class="counter">120</span>K+
                                    </div>
                                    <p class="icon-content-info">Companies Jobs</p>
                                </div>
                            </div>


                            <div class="twm-bnr-blocks twm-bnr-blocks-position-2">
                                <div class="twm-icon pink">
                                    <img src="<?php echo e(asset('assets/frontend/user/images/main-slider/slider2/icon-2.png')); ?>" alt="">
                                </div>
                                <div class="twm-content">
                                    <div class="tw-count-number text-clr-pink">
                                        <span class="counter">98</span> +
                                    </div>
                                    <p class="icon-content-info">Job For Countries </p>
                                </div>
                            </div>


                            <div class="twm-bnr-blocks-3 twm-bnr-blocks-position-3">
                                <div class="twm-pics">
                                    <span><img src="<?php echo e(asset('assets/frontend/user/images/main-slider/slider2/user/u-1.jpg')); ?>"
                                            alt=""></span>
                                    <span><img src="<?php echo e(asset('assets/frontend/user/images/main-slider/slider2/user/u-2.jpg')); ?>"
                                            alt=""></span>
                                    <span><img src="<?php echo e(asset('assets/frontend/user/images/main-slider/slider2/user/u-3.jpg')); ?>"
                                            alt=""></span>
                                    <span><img src="<?php echo e(asset('assets/frontend/user/images/main-slider/slider2/user/u-4.jpg')); ?>"
                                            alt=""></span>
                                    <span><img src="<?php echo e(asset('assets/frontend/user/images/main-slider/slider2/user/u-5.jpg')); ?>"
                                            alt=""></span>
                                    <span><img src="<?php echo e(asset('assets/frontend/user/images/main-slider/slider2/user/u-6.jpg')); ?>"
                                            alt=""></span>
                                </div>
                                <div class="twm-content">
                                    <div class="tw-count-number text-clr-green2">
                                        <span class="counter">30</span>K+
                                    </div>
                                    <p class="icon-content-info">Jobs Done</p>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="twm-search-bar-2-wrap mobile_display_none">
            <div class="container">
                <div class="twm-search-bar-2-inner">

                    <div class="row">

                        <div class="col-lg-12 col-md-12">
                            <div class="twm-bnr-search-bar">
                                <form method="post" action="#">
                                    <input type="hidden" name="_token"
                                        value="TKltWQYXrA5R1WcBYM8K11PRNQeONOE56JlAs1b7">
                                    <div class="row">

                                        <div class="form-group col-lg-3 col-md-6">
                                            <label>Type</label>
                                            <select class="wt-search-bar-select selectpicker select_job_type"
                                                onchange="categoryChange()" name="job_type" required>

                                                <option value="">Select Type</option>
                                                <option value="group_job">Group Jobs</option>
                                                <option value="personal_job">Personal Jobs</option>
                                                <option value="service">Services</option>
                                            </select>
                                        </div>


                                        <div class="form-group col-lg-3 col-md-6">
                                            <label>Category</label>
                                            <select class="wt-search-bar-select selectpicker" name="category" id="search-category">

                                            </select>
                                        </div>


                                        <div class="form-group col-lg-3 col-md-6">
                                            <label>Job Keywords</label>
                                            <div class="twm-inputicon-box">
                                                <input type="text" class="form-control" name="keyword"
                                                    placeholder="Keywords">
                                                <i class="twm-input-icon fa-solid fa-key"></i>
                                            </div>
                                        </div>


                                        <div class="form-group col-lg-3 col-md-6">
                                            <button type="submit" class="site-button">Find Jobs</button>
                                        </div>

                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>


                </div>
            </div>
        </div>


        <div class="section-full p-t100 p-b40 site-bg-white twm-how-it-work-area2" id="howitwork">

            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-12">

                        <div class="section-head left wt-small-separator-outer">
                            <div class="wt-small-separator site-text-primary">
                                <div>How It Works </div>
                            </div>
                            <h2 class="wt-title"><?php echo e($step->heading); ?></h2>
                            <p><?php echo e($step->text); ?></p>
                        </div>
                        <ul class="description-list">
                            <li>
                                <i class="feather-check"></i>
                                <?php echo e($step->check_1); ?>

                            </li>
                            <li>
                                <i class="feather-check"></i>
                                <?php echo e($step->check_2); ?>

                            </li>
                            <li>
                                <i class="feather-check"></i>
                                <?php echo e($step->check_3); ?>

                            </li>
                            <li>
                                <i class="feather-check"></i>
                                <?php echo e($step->check_4); ?>

                            </li>
                        </ul>

                    </div>
                    <div class="col-lg-8 col-md-12">
                        <div class="twm-w-process-steps-2-wrap">
                            <div class="row">
                                <div class="col-xl-6 col-lg-6 col-md-6">
                                    <div class="twm-w-process-steps-2">
                                        <div
                                            class="twm-w-pro-top bg-clr-sky-light bg-sky-light-shadow block-gradient">
                                            <span class="twm-large-number text-clr-white">01</span>
                                            <div class="twm-media">
                                                <span><img src="<?php echo e(asset($step->step_one_icon)); ?>"
                                                        alt="icon1"></span>
                                            </div>
                                            <h4 class="twm-title"><?php echo e($step->step_one_title); ?></h4>
                                            <p><?php echo e($step->step_one_text); ?></p>
                                        </div>

                                    </div>
                                </div>

                                <div class="col-xl-6 col-lg-6 col-md-6">
                                    <div class="twm-w-process-steps-2">
                                        <div
                                            class="twm-w-pro-top bg-clr-yellow-light bg-yellow-light-shadow block-gradient-2">
                                            <span class="twm-large-number text-clr-white">02</span>
                                            <div class="twm-media">
                                                <span><img src="<?php echo e(asset($step->step_one_icon)); ?>"
                                                        alt="icon1"></span>
                                            </div>
                                            <h4 class="twm-title"><?php echo e($step->step_one_title); ?></h4>
                                            <p><?php echo e($step->step_one_text); ?></p>
                                        </div>

                                    </div>
                                </div>

                                <div class="col-xl-6 col-lg-6 col-md-6">
                                    <div class="twm-w-process-steps-2">
                                        <div
                                            class="twm-w-pro-top bg-clr-pink-light bg-pink-light-shadow block-gradient-3">
                                            <span class="twm-large-number text-clr-white">03</span>
                                            <div class="twm-media">
                                                <span><img src="<?php echo e(asset($step->step_one_icon)); ?>"
                                                        alt="icon1"></span>
                                            </div>
                                            <h4 class="twm-title"><?php echo e($step->step_one_title); ?></h4>
                                            <p><?php echo e($step->step_one_text); ?></p>
                                        </div>

                                    </div>
                                </div>

                                <div class="col-xl-6 col-lg-6 col-md-6">
                                    <div class="twm-w-process-steps-2">
                                        <div
                                            class="twm-w-pro-top bg-clr-green-light bg-clr-light-shadow block-gradient-4">
                                            <span class="twm-large-number text-clr-white">04</span>
                                            <div class="twm-media">
                                                <span><img src="<?php echo e(asset($step->step_one_icon)); ?>"
                                                        alt="icon1"></span>
                                            </div>
                                            <h4 class="twm-title"><?php echo e($step->step_one_title); ?></h4>
                                            <p><?php echo e($step->step_one_text); ?></p>
                                        </div>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>



                <div class="twm-how-it-work-section">

                </div>
            </div>

        </div>





        <div class="section-full p-t80 p-b70 site-bg-gray twm-bg-ring-wrap2">
            <div class="twm-bg-ring-right"></div>
            <div class="twm-bg-ring-left"></div>
            <div class="container">

                <div class="wt-separator-two-part">
                    <div class="row wt-separator-two-part-row">
                        <div class="col-xl-6 col-lg-6 col-md-12 wt-separator-two-part-left">

                            <div class="section-head left wt-small-separator-outer">
                                <div class="wt-small-separator site-text-primary">
                                    <div>All Jobs Post</div>
                                </div>
                                <h2 class="wt-title">Find Your Career You Deserve it</h2>
                            </div>

                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-12 wt-separator-two-part-right text-right">
                            <ul class="nav nav-tabs project-tab justify-content-md-end justify-content-start"
                                id="project-tab" role="tablist" style="width:360px">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="home-tab" data-bs-toggle="tab"
                                        data-bs-target="#home" type="button" role="tab" aria-controls="home"
                                        aria-selected="true">Group Jobs</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="profile-tab" data-bs-toggle="tab"
                                        data-bs-target="#profile" type="button" role="tab" aria-controls="profile"
                                        aria-selected="false">Personal Jobs</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="contact-tab" data-bs-toggle="tab"
                                        data-bs-target="#contact" type="button" role="tab" aria-controls="contact"
                                        aria-selected="false">Gig</button>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div>
                </div>

                <div class="section-content mt-3">
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <div class="twm-jobs-grid-wrap">
                                <div class="row">
                                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo $__env->make('partials.job-post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                            <div class="twm-jobs-grid-wrap">
                                <div class="row">
                                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo $__env->make('partials.job-post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                            <div class="twm-jobs-grid-wrap">
                                <div class="row">
                                    <?php $__currentLoopData = $gigs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $gig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo $__env->make('partials.gig', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>





        <div class="section-full p-t60 p-b60 twm-for-employee-area site-bg-white">
            <div class="container">

                <div class="section-content">
                    <div class="row">

                        <div class="col-lg-5 col-md-12">
                            <div class="twm-explore-media-wrap">
                                <div class="twm-media">
                                    <img src="<?php echo e(asset($about->image)); ?>" alt="<?php echo e($about->title); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-7 col-md-12">
                            <div class="twm-explore-content-outer-3">

                                <div class="twm-explore-content-3">
                                    <div class="twm-title-small">About Us</div>
                                    <div class="twm-title-large">
                                        <h2><?php echo e($about->title); ?></h2>
                                        <p><?php echo e($about->description); ?></p>
                                    </div>
                                    <div class="twm-upload-file">
                                        <button type="button" class="site-button">Read More <i class="feather-chevron-right"></i></button>
                                    </div>

                                </div>

                                <div class="twm-l-line-1"></div>
                                <div class="twm-l-line-2"></div>

                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>





        <div class="section-full p-t80 p-b80 site-bg-gray twm-testimonial-2-area">


            <div class="section-head center wt-small-separator-outer">
                <div class="wt-small-separator site-text-primary">
                    <div>Clients Testimonials</div>
                </div>
                <h2 class="wt-title">What Our Customers Say About Us</h2>
            </div>


            <div class="container">

                <div class="section-content">

                    <div class="owl-carousel twm-testimonial-2-carousel owl-btn-bottom-center ">

                        <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item ">
                                <div class="twm-testimonial-2">
                                    <div class="twm-testimonial-2-content">
                                        <div class="twm-testi-media">
                                            <img src="<?php echo e(asset($testimonial->image)); ?>" alt="<?php echo e($testimonial->name); ?>">
                                        </div>
                                        <div class="twm-testi-content">
                                            <div class="twm-quote">
                                                <img src="<?php echo e(asset('assets/frontend/user/images/quote-dark.png')); ?>" alt="">
                                            </div>
                                            <div class="twm-testi-info"><?php echo e($testimonial->description); ?></div>
                                            <div class="twm-testi-detail">
                                                <div class="twm-testi-name"><?php echo e($testimonial->name); ?></div>
                                                <div class="twm-testi-position"><?php echo e($testimonial->title); ?></div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>



        <div class="section-full p-t60 p-b60 site-bg-white twm-companies-wrap">

            <div class="section-head center wt-small-separator-outer mb-2 mb-md-5">
                <div class="wt-small-separator site-text-primary">
                    <div>Payment Gateway</div>
                </div>
                <h2 class="wt-title">Our Payment Partner's</h2>
            </div>
            <div class="container">
                <div class="section-content">
                    <div class="owl-carousel home-client-carousel2 owl-btn-vertical-center">
                        <?php $__currentLoopData = $getways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo client-logo-media">
                                        <a href="javascript:void(0);">
                                            <img src="<?php echo e(asset($getway->logo)); ?>" alt="">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\GpsFreelancer\resources\views\welcome.blade.php ENDPATH**/ ?>