<div class="col-12">
    <div class="micro-job-wrapper d-flex justify-content-between flex-wrap align-items-center">
        <div class="micro-left-content two">
            <div class="m-tag-wrap">
                
                <a href="#"><span><?php echo e($job->jobWithCategoryRelation->category_name); ?></span></a>
            </div>
            <a href="<?php echo e(route('user.job.details', $job->id)); ?>" class="m-link">
                <h5 class="m-title"><?php echo e($job->title); ?></h5>
            </a>
            <div class="m-expertise-wrap d-flex ">
                
                    <span class="m-icon"><i class="fa-solid fa-explosion"></i></span><span
                        class="m-expertise">
                        Level <?php echo e($job->user_level); ?>

                    </span>
                </p>
            </div>
        </div>
        <div class="micro-middle-content two">
            <div class="progress-wrapper">

                <div class="progress-counter text-center">
                    <p class="mb-0"><span><?php echo e(submitedJob($job->id)); ?></span> of <span><?php echo e($job->total_worker_needed); ?></span> done</p>
                </div>
                <div class="progress custom-progress">
                    <div class="progress-bar" style="width:<?php echo e($job->total_worker_needed * submitedJob($job->id) / 100); ?>%"></div>
                </div>
            </div>

        </div>
        <div class="micro-right-content two">
            <div class="m-action-wrap text-end">
                <span> <a href="<?php echo e(route('user.job.details', $job->id)); ?>" class="text-muted" target="blank"><i class="fa-solid fa-up-right-from-square"></i></a></span>
            </div>
            <div class="m-price-wrap text-end">
                <p>$ <?php echo e($job->each_worker_earn); ?></p>
            </div>
            <div class="m-duration text-end">
            </div>
        </div>
    </div>
</div>
<?php /**PATH F:\xampp\htdocs\GpsFreelancer\resources\views\partials\job-post.blade.php ENDPATH**/ ?>