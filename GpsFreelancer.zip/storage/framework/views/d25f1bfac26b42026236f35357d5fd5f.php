<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
<footer class="main-footer">
    <strong>Copyright &copy; 2023 <a href="<?php echo e(route('frontend.index')); ?>"><?php echo e(setting()->site_name); ?></a>.</strong>
    All rights reserved.
    
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="<?php echo e(asset('assets/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap -->
<script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE -->
<script src="<?php echo e(asset('assets/dist/js/adminlte.js')); ?>"></script>

<!-- OPTIONAL SCRIPTS -->
<script src="<?php echo e(asset('assets/plugins/chart.js/Chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dist/js/demo.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dist/js/pages/dashboard3.js')); ?>"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>

<?php if(session('success')): ?>
    <script>
        swal({
            title: "Success",
            text: "<?php echo e(session('success')); ?>",
            icon: "success",
            button: "Ok",
        });
    </script>
<?php endif; ?>
<?php if(session('error')): ?>
    <script>
        swal({
            title: "Error",
            text: "<?php echo e(session('error')); ?>",
            icon: "error",
            button: "Ok",
        });
    </script>
<?php endif; ?>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH F:\xampp\htdocs\GpsFreelancer\resources\views/admin/partials/footer.blade.php ENDPATH**/ ?>