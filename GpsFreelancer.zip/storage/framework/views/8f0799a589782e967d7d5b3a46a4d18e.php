<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Edit Plan</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active">Edit Plan</li>
                    </ol>
                </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>

        <section class="content">
            <div class="container-fluid">
              <div class="row justify-content-center">
                <div class="col-lg-8">
                  <div class="card card-primary">
                    <div class="card-header">
                      <h3 class="card-title">Edit Plan</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form role="form" action="<?php echo e(route('plan.update', $data->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                      <div class="card-body">
                          <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="plan_name">Plan Name</label>
                                    <input type="text" name="plan_name" class="form-control" id="plan_name" placeholder="Enter plan name" value="<?php echo e(old('plan_name') ?? $data->plan_name); ?>">
                                    <?php $__errorArgs = ['plan_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="price">Price</label>
                                    <input type="number" min="1" step="1" name="price" class="form-control" id="price" placeholder="Enter price" value="<?php echo e(old('price') ?? $data->price); ?>">
                                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label for="job_post_fee">Job Post Fee</label>
                                    <div class="input-group">
                                        <input type="number" min="1" max="100" step="1" name="job_post_fee" class="form-control" id="job_post_fee" value="<?php echo e(old('job_post_fee') ?? $data->job_post_fee); ?>" placeholder="Enter job post fee">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="job_post_fee">%</span>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['job_post_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label for="withdraw_fee">Withdraw Fee</label>
                                    <div class="input-group">
                                        <input type="number" min="1" max="100" step="1" name="withdraw_fee" class="form-control" id="withdraw_fee" value="<?php echo e(old('withdraw_fee') ?? $data->withdraw_fee); ?>" placeholder="Enter withdraw fee">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="withdraw_fee">%</span>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['withdraw_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label for="post_bost_duration">Post Bost Duration</label>
                                    <div class="input-group">
                                        <input type="number" min="1" max="100" step="1" name="post_bost_duration" class="form-control" id="post_bost_duration" value="<?php echo e(old('post_bost_duration') ?? $data->post_bost_duration); ?>" placeholder="Enter post bost duration">
                                    </div>
                                    <?php $__errorArgs = ['post_bost_duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label for="daily_spin_limit">Daily Spin Limit</label>
                                    <div class="input-group">
                                        <input type="number" min="1" max="100" step="1" name="daily_spin_limit" class="form-control" id="daily_spin_limit" value="<?php echo e(old('daily_spin_limit') ?? $data->daily_spin_limit); ?>" placeholder="Enter daily spin limit">
                                    </div>
                                    <?php $__errorArgs = ['daily_spin_limit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label for="deposit_refer_commission">Deposit Refer Commission</label>
                                    <div class="input-group">
                                        <input type="number" min="1" max="100" step="1" name="deposit_refer_commission" class="form-control" id="deposit_refer_commission" value="<?php echo e(old('deposit_refer_commission') ?? $data->deposit_refer_commission); ?>" placeholder="Enter deposit refer commission">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="deposit_refer_commission">%</span>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['deposit_refer_commission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label for="task_commission">Task Commission</label>
                                    <div class="input-group">
                                        <input type="number" min="1" max="100" step="1" name="task_commission" class="form-control" id="task_commission" value="<?php echo e(old('task_commission') ?? $data->task_commission); ?>" placeholder="Enter task commission">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="task_commission">%</span>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['task_commission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <div class="form-group">
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input" id="geen_mark_badge" name="geen_mark_badge" value="yes" <?php echo e($data->geen_mark_badge == 'yes' ? 'checked' : ''); ?>>
                                            <label class="custom-control-label" for="geen_mark_badge">Green Mark Badge</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <div class="form-group">
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input" id="profile_mark_badge" name="profile_mark_badge" value="yes" <?php echo e($data->profile_mark_badge == 'yes' ? 'checked' : ''); ?>>
                                            <label class="custom-control-label" for="profile_mark_badge">Profile Mark Badge</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <div class="form-group">
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input" id="live_phone_call_support" name="live_phone_call_support" value="yes" <?php echo e($data->live_phone_call_support == 'yes' ? 'checked' : ''); ?>>
                                            <label class="custom-control-label" for="live_phone_call_support">Live Phone Call Support</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                      </div>
                      <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Save & Update</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\GpsFreelancer\resources\views\admin\plan\edit.blade.php ENDPATH**/ ?>