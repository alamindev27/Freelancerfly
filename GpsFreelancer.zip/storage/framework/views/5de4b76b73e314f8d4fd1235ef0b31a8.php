<div class="col-lg-4 col-md-12 m-b10 ">
    <div class="gigs-wrapper">
        <div class="gigs-image">
            <div id="demo-<?php echo e($key); ?>" class="carousel slide" data-bs-ride="carousel" data-bs-interval="false" data-bs-pause="hover">

                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#demo-<?php echo e($key); ?>" data-bs-slide-to="0" class="<?php echo e($key == 0 ? 'active' : ''); ?>"></button>
                </div>


                <div class="carousel-inner">
                    <?php $__currentLoopData = banners($gig->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item <?php echo e($key2 == 0 ? 'active' : ''); ?>">
                            <img src="<?php echo e(asset($banner->banner)); ?>" alt="Los Angeles" class="d-block" style="width:100%">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#demo-<?php echo e($key); ?>" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </button>

                <button class="carousel-control-next" type="button" data-bs-target="#demo-<?php echo e($key); ?>" data-bs-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </button>
            </div>

        </div>
        <div class="gigs-content">
            <a href="<?php echo e(route('both.gig.details', $gig->id)); ?>" class="twm-job-title">
                <h4><?php echo e($gig->title); ?></h4>
            </a>
            
        </div>
        <div class="gigs-footer d-flex justify-content-between align-items-center">
            <div class="gigs-content-left">
            </div>
            <div class="gigs-content-right">
                <span><small>STARTING AT</small> $ <?php echo e($gig->basic_price); ?></span>
            </div>
        </div>
    </div>
</div>
<?php /**PATH F:\xampp\htdocs\GpsFreelancer\resources\views/partials/gig.blade.php ENDPATH**/ ?>