<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <label for="country-<?php echo e($country->id); ?>" class="country-exclude-item">
        <div>
            <?php echo e($country->name); ?>

        </div>
        <input id="country-<?php echo e($country->id); ?>" type="checkbox" name="country_id[]" class="country_input" value="<?php echo e($country->id); ?>" country_name="<?php echo e($country->name); ?>">
    </label>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH F:\xampp\htdocs\GpsFreelancer\resources\views/client/get-country.blade.php ENDPATH**/ ?>