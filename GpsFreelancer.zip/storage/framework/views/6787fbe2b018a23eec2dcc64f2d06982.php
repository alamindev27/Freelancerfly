<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php if($user->sender_id == auth()->user()->id): ?>
        <div class="wt-dashboard-msg-search-list-wrap">
            <a href="<?php echo e(route('both.message.chat', $user->id)); ?>" class="msg-user-info clearfix conversation_21587" conversation_id="21587">
                <div class="msg-user-timing"></div>
                <div class="msg-user-info-pic">
                    <img src="<?php echo e(getUser($user->resiver_id)->avatar); ?>" alt="<?php echo e(getUser($user->resiver_id)->name); ?>">
                </div>
                <div class="msg-user-info-text">
                    <div class="msg-user-name"> <?php echo e(getUser($user->resiver_id)->name); ?></div>
                    <div class="msg-user-discription  text-muted"><?php echo e($user->message); ?></div>
                </div>
            </a>
        </div>
    <?php else: ?>
        <div class="wt-dashboard-msg-search-list-wrap">
            <a href="<?php echo e(route('both.message.chat', $user->id)); ?>" class="msg-user-info clearfix conversation_21587" conversation_id="21587">
                <div class="msg-user-timing"></div>
                <div class="msg-user-info-pic">
                    <img src="<?php echo e(asset(getUser($user->sender_id)->avatar)); ?>" alt="<?php echo e(getUser($user->sender_id)->name); ?>">
                </div>
                <div class="msg-user-info-text">
                    <div class="msg-user-name"> <?php echo e(getUser($user->sender_id)->name); ?></div>
                    <div class="msg-user-discription  text-muted"><?php echo e($user->message); ?></div>
                </div>
            </a>
        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="text-center text-danger">
        <h4>No chat available</h4>
    </div>
<?php endif; ?>
<?php /**PATH F:\xampp\htdocs\GpsFreelancer\resources\views/partials/message-sidebar.blade.php ENDPATH**/ ?>