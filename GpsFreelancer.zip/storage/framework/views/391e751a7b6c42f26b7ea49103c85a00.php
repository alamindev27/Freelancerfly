<?php $__env->startSection('styles'); ?>
    <style>
        .all-dashboard-icon {
            width: 13px !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-wraper" style="transform: none;">
        <div class="page-content" style="transform: none;">
            <div class="section-full p-t70  p-b70 site-bg-white" style="transform: none;">
                <div class="container" style="transform: none;">
                    <div class="row" style="transform: none;">

                        <?php echo $__env->make('partials.profile-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                        <div class="col-xl-9 col-lg-8 col-md-12 m-b30">
                            <div class="twm-right-section-panel site-bg-gray">
                                <div class="panel panel-default">
                                    <div class="panel-heading wt-panel-heading p-a20">
                                        <h4 class="panel-tittle m-a0"><svg style="width: 20px" class="svg-inline--fa fa-suitcase me-2"
                                                aria-hidden="true" focusable="false" data-prefix="fas" data-icon="suitcase"
                                                role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"
                                                data-fa-i2svg="">
                                                <path fill="currentColor"
                                                    d="M176 56V96H336V56c0-4.4-3.6-8-8-8H184c-4.4 0-8 3.6-8 8zM128 96V56c0-30.9 25.1-56 56-56H328c30.9 0 56 25.1 56 56V96v32V480H128V128 96zM64 96H96V480H64c-35.3 0-64-28.7-64-64V160c0-35.3 28.7-64 64-64zM448 480H416V96h32c35.3 0 64 28.7 64 64V416c0 35.3-28.7 64-64 64z">
                                                </path>
                                            </svg><!-- <i class="fa fa-suitcase me-2"></i> Font Awesome fontawesome.com -->Inbox
                                        </h4>
                                    </div>
                                    <div class="panel-body wt-panel-body p-a20 m-b30 ">
                                        <div class="wt-admin-dashboard-msg-2 active">

                                            <div class="wt-dashboard-msg-user-list">
                                                <div class="user-msg-list-btn-outer">
                                                    <button class="user-msg-list-btn-close">Close</button>
                                                    <button class="user-msg-list-btn-open">User Message</button>
                                                </div>

                                                



                                                



                                                <div class="scroll-wrapper wt-dashboard-msg-search-list scrollbar-macosx"
                                                    style="position: relative;">
                                                    <div class="wt-dashboard-msg-search-list scrollbar-macosx scroll-content" id="conversation_list" style="position: relative; height: 700px; margin-bottom: 0px; margin-right: 0px; max-height: none;">

                                                        <?php echo $__env->make('partials.message-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                                    </div>
                                                    <div class="scroll-element scroll-x">
                                                        <div class="scroll-element_outer">
                                                            <div class="scroll-element_size"></div>
                                                            <div class="scroll-element_track"></div>
                                                            <div class="scroll-bar" style="width: 0px;"></div>
                                                        </div>
                                                    </div>
                                                    <div class="scroll-element scroll-y">
                                                        <div class="scroll-element_outer">
                                                            <div class="scroll-element_size"></div>
                                                            <div class="scroll-element_track"></div>
                                                            <div class="scroll-bar" style="height: 0px;"></div>
                                                        </div>
                                                    </div>
                                                </div>


                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>


                        




                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\GpsFreelancer\resources\views/both/message.blade.php ENDPATH**/ ?>