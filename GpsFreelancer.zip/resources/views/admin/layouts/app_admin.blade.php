@include('admin.partials.header')
<!-- Main Sidebar Container -->
@include('admin.partials.sidebar')
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    @yield('content')
</div>
<!-- /.content-wrapper -->
<!-- Main Footer -->
@include('admin.partials.footer')
