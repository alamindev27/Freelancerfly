@include('partials.header')
@include('partials.menu')
@yield('content')
@include('partials.footer')
